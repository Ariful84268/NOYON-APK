# NOYON BROWSER (APK প্রজেক্ট)

আপনার `NOYON-BROWSER.html` পেজটাই অ্যাপের হোম পেজ (`app/src/main/assets/index.html`)।
গুগল/ইউটিউব/ফেসবুক ইত্যাদি আইকনে চাপলে সাইট অ্যাপের ভেতরেই খোলে। ব্যাক চাপলে আগের পেজ, শেষে হোম পেজ।
ছবি বদলানো, থিম রং (localStorage), ফাইল ডাউনলোড, ফুলস্ক্রিন ভিডিও আর মাইক/ক্যামেরার পারমিশন কাজ করবে।

## বিল্ড ফেইল হচ্ছিল কেন
আগের বিল্ডে রিপোতে শুধু HTML ফাইল ছিল। অ্যান্ড্রয়েড প্রজেক্টের ফাইল (`settings.gradle`, `app` ফোল্ডার, `gradlew`) না থাকায় Actions ১২ সেকেন্ডে থেমে গিয়েছিল।

## আপলোড
এই zip-এর ভেতরের সব ফাইল ও ফোল্ডার (`.github`, `app`, `gradle`, `gradlew`, `settings.gradle` ইত্যাদি) রিপোর মূল জায়গায় রাখুন।
ফোন থেকে ফোল্ডার আপলোড কঠিন হলে: zip ফাইলটাই রিপোতে আপলোড করুন আর শুধু `build.yml` (`.github/workflows/build.yml`) আপডেট করে নিন — এই build.yml zip খুলে নিজেই বিল্ড করবে।
তারপর Actions → Build APK → Run workflow। শেষ হলে নিচের Artifacts থেকে `NOYON-BROWSER-debug-apk` নামান।
